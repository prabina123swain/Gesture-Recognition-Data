# Sign_Lang_Detection_1 > 2025-03-23 12:36am
https://universe.roboflow.com/prabina/sign_lang_detection_1

Provided by a Roboflow user
License: CC BY 4.0

