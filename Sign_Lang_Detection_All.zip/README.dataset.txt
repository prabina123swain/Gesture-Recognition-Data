# Sign_Lang_Detection_All > 2025-03-23 11:22pm
https://universe.roboflow.com/prabina/sign_lang_detection_all-gwxjr

Provided by a Roboflow user
License: CC BY 4.0

