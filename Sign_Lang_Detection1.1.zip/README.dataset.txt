# Sign_Lang_Detection > 2025-03-23 12:07pm
https://universe.roboflow.com/prabina/sign_lang_detection-uzwn3

Provided by a Roboflow user
License: CC BY 4.0

