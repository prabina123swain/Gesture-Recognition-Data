# sing lang detection > 2025-03-10 12:38pm
https://universe.roboflow.com/prabina/sing-lang-detection

Provided by a Roboflow user
License: CC BY 4.0

